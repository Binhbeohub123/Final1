/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author ASUS
 */
public class Caidat {
    private String TaiKhoanID;
    private String VTID;      // Vai trò ID
    private String Email;
    private String MatKhau;
    private boolean trangthai;

    // Constructor mặc định (nếu cần)
    public Caidat() {
    }

    // Constructor 1 tham số (nếu dùng để set VTID)
    public Caidat(String VTID) {
        this.VTID = VTID;
    }

    // Constructor đầy đủ
    public Caidat(String TaiKhoanID, String VTID, String Email, String MatKhau, boolean trangthai) {
        this.TaiKhoanID = TaiKhoanID;
        this.VTID = VTID;
        this.Email = Email;
        this.MatKhau = MatKhau;
        this.trangthai = trangthai;
    }

    // Getter và Setter
    public String getTaiKhoanID() {
        return TaiKhoanID;
    }

    public void setTaiKhoanID(String TaiKhoanID) {
        this.TaiKhoanID = TaiKhoanID;
    }

    public String getVTID() {
        return VTID;
    }

    public void setVTID(String VTID) {
        this.VTID = VTID;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public boolean isTrangthai() {
        return trangthai;
    }

    public void setTrangthai(boolean trangthai) {
        this.trangthai = trangthai;
    }
}
