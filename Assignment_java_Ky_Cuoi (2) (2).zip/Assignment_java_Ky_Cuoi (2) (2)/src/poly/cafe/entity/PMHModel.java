package poly.cafe.entity;

import java.util.ArrayList;
import java.util.List;

public class PMHModel {
    private String maHD; 
    private String ngayLap; 
    private String tenNV; 
    private double phiPhuThu; 
    private String ghiChu; 
    private double tongTien; 
    private boolean daThanhToan; 
    private boolean daHuy; 
    private String the;
    private List<Sanpham> chiTietSanPham; 

    public PMHModel() {
        this.chiTietSanPham = new ArrayList<>();
        this.daThanhToan = false;
        this.daHuy = false; // Mặc định là chưa hủy
    }

    public PMHModel(String maHD, String ngayLap, String tenNV, double phiPhuThu, String ghiChu, double tongTien, boolean daThanhToan, String the) {
        this.maHD = maHD;
        this.ngayLap = ngayLap;
        this.tenNV = tenNV;
        this.phiPhuThu = phiPhuThu;
        this.ghiChu = ghiChu;
        this.tongTien = tongTien;
        this.daThanhToan = daThanhToan;
        this.daHuy = false; // Mặc định là chưa hủy
        this.chiTietSanPham = new ArrayList<>();
        this.the = the;
    }
    public String getThe() {
        return the;
    }

    public void setThe(String the) {
        this.the = the;
    }
    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getNgayLap() {
        return ngayLap;
    }

    public void setNgayLap(String ngayLap) {
        this.ngayLap = ngayLap;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public double getPhiPhuThu() {
        return phiPhuThu;
    }

    public void setPhiPhuThu(double phiPhuThu) {
        this.phiPhuThu = phiPhuThu;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public double getTongTien() {
        return tongTien;
    }

    public void setTongTien(double tongTien) {
        this.tongTien = tongTien;
    }

    public boolean isDaThanhToan() {
        return daThanhToan;
    }

    public void setDaThanhToan(boolean daThanhToan) {
        this.daThanhToan = daThanhToan;
    }

    public boolean isDaHuy() { // Thêm getter cho DaHuy
        return daHuy;
    }

    public void setDaHuy(boolean daHuy) { // Thêm setter cho DaHuy
        this.daHuy = daHuy;
    }

    public List<Sanpham> getChiTietSanPham() {
        return chiTietSanPham;
    }

    public void setChiTietSanPham(List<Sanpham> chiTietSanPham) {
        this.chiTietSanPham = chiTietSanPham;
    }

    public void addSanpham(Sanpham sp) {
        this.chiTietSanPham.add(sp);
    }
}