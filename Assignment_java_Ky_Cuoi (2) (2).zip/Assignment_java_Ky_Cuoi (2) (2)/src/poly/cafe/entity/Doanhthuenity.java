package poly.cafe.entity;

public class Doanhthuenity {

    public Doanhthuenity(String maSP, String tenSP, String loaiSP, String tenNV, long doanhThu) {
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.loaiSP = loaiSP;
        this.tenNV = tenNV;
        this.doanhThu = doanhThu;
    }
    private String maSP;
    private String tenSP;
    private String loaiSP;
    private String tenNV;
    private long doanhThu;

    // Nếu có thống kê ngày thì thêm:
    // private LocalDate ngay;

    // Getters & Setters
    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getLoaiSP() {
        return loaiSP;
    }

    public void setLoaiSP(String loaiSP) {
        this.loaiSP = loaiSP;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public long getDoanhThu() {
        return doanhThu;
    }

    public void setDoanhThu(long doanhThu) {
        this.doanhThu = doanhThu;
    }
    public Doanhthuenity(String maSP, String tenSP, String loaiSP, long doanhThu) {
    this.maSP = maSP;
    this.tenSP = tenSP;
    this.loaiSP = loaiSP;
    this.doanhThu = doanhThu;
}
}

