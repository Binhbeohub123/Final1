/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;

import java.util.Date;

/**
 *
 * @author NTL
 */
public class ThongkeNV {
    private int id;
    private String tenNV;
    private double tongTien;
    private boolean daThanhToan;
    private boolean daHuy;
    private Date ngay; 


    public ThongkeNV() {}

   
    public ThongkeNV(String tenNV, double tongTien) {
        this.tenNV = tenNV;
        this.tongTien = tongTien;
    }

   
    public ThongkeNV(String tenNV, double tongTien, Date ngay) {
        this.tenNV = tenNV;
        this.tongTien = tongTien;
        this.ngay = ngay;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTenNV() { return tenNV; }
    public void setTenNV(String tenNV) { this.tenNV = tenNV; }

    public double getTongTien() { return tongTien; }
    public void setTongTien(double tongTien) { this.tongTien = tongTien; }

    public boolean isDaThanhToan() { return daThanhToan; }
    public void setDaThanhToan(boolean daThanhToan) { this.daThanhToan = daThanhToan; }

    public boolean isDaHuy() { return daHuy; }
    public void setDaHuy(boolean daHuy) { this.daHuy = daHuy; }

    public Date getNgay() {
        return ngay;
    }

    public void setNgay(Date ngay) {
        this.ngay = ngay;
    }
}
