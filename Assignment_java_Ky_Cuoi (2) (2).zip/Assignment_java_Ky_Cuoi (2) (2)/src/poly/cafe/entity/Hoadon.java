/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;
import java.util.Date;
/**
 *
 * @author ASUS
 */
public class Hoadon {
     private String idBills;
    private Date ngayLap;
    private String idNV;
    private String ghiChu;
    private double phuThu;

    public Hoadon(String idBills, Date ngayLap, String idNV, String ghiChu, double phuThu) {
        this.idBills = idBills;
        this.ngayLap = ngayLap;
        this.idNV = idNV;
        this.ghiChu = ghiChu;
        this.phuThu = phuThu;
    }

    public String getIdBills() {
        return idBills;
    }

    public void setIdBills(String idBills) {
        this.idBills = idBills;
    }

    public Date getNgayLap() {
        return ngayLap;
    }

    public void setNgayLap(Date ngayLap) {
        this.ngayLap = ngayLap;
    }

    public String getIdNV() {
        return idNV;
    }

    public void setIdNV(String idNV) {
        this.idNV = idNV;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public double getPhuThu() {
        return phuThu;
    }

    public void setPhuThu(double phuThu) {
        this.phuThu = phuThu;
    }
    
}
