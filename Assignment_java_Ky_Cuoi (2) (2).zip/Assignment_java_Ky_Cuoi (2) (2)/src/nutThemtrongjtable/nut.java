 
package nutThemtrongjtable;

import javax.swing.JButton;
import javax.swing.border.EmptyBorder;
public class nut extends JButton  {
    public nut(){
        setContentAreaFilled(false);
        setBorder(new EmptyBorder(3, 3, 3, 3));
}
}
