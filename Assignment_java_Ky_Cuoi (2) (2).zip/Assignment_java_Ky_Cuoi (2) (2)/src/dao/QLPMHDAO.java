package dao;

import DBCONNEC.Connect;
import poly.cafe.entity.PMHModel;
import poly.cafe.entity.Sanpham;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QLPMHDAO {
    public List<PMHModel> getUnpaidOrders() {
        List<PMHModel> list = new ArrayList<>();
        String sql = "SELECT h.MaHD, h.NgayLap, h.TenNV, h.PhiPhuThu, h.GhiChu, h.TongTien, h.DaThanhToan,h.The, " +
                     "c.MaSP, c.SoLuong, c.Gia, s.TenSP, s.LoaiSP " +
                     "FROM PhieuMuaHang h " +
                     "LEFT JOIN ChiTietPhieu c ON h.MaHD = c.MaHD " + 
                     "LEFT JOIN QLSP s ON c.MaSP = s.MaSP " +
                     "WHERE h.DaThanhToan = ?";
        
        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, false);
            ResultSet rs = pstmt.executeQuery();
            
            PMHModel currentOrder = null;
            String currentMaHD = null;
            
            while (rs.next()) {
                String maHD = rs.getString("MaHD");
                if (!maHD.equals(currentMaHD)) {
                    if (currentOrder != null) list.add(currentOrder);
                    currentOrder = new PMHModel();
                    currentOrder.setMaHD(maHD);
                    currentOrder.setNgayLap(rs.getString("NgayLap"));
                    currentOrder.setTenNV(rs.getString("TenNV"));
                    currentOrder.setPhiPhuThu(rs.getDouble("PhiPhuThu"));
                    currentOrder.setGhiChu(rs.getString("GhiChu"));
                    currentOrder.setTongTien(rs.getDouble("TongTien"));
                    currentOrder.setDaThanhToan(rs.getBoolean("DaThanhToan"));
                    currentOrder.setThe(rs.getString("the"));
                    currentMaHD = maHD;
                }
                String maSP = rs.getString("MaSP");
                if (maSP != null) {
                    Sanpham sp = new Sanpham();
                    sp.setMASP(maSP);
                    sp.setTENSP(rs.getString("TenSP"));
                    sp.setLOAISP(rs.getString("LoaiSP"));
                    sp.setGIA(rs.getDouble("Gia"));
                    sp.setSoLuong(rs.getInt("SoLuong"));
                    currentOrder.addSanpham(sp);
                }
            }
            if (currentOrder != null) list.add(currentOrder);
            
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách phiếu mua hàng: " + e.getMessage());
        }
        
        return list;
    }
}