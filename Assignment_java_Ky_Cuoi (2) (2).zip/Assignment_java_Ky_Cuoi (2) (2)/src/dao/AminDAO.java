package dao;

import DBCONNEC.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AminDAO {
    // Thêm tham chiếu JFrame để hiển thị thông báo
    private final JFrame parent;

    public AminDAO(JFrame parent) {
        this.parent = parent;
    }

    public List<String> getUserEmails() {
        List<String> userEmails = new ArrayList<>();
        String sql = "SELECT Email FROM Users";
        try (Connection conn = Connect.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (conn == null) {
                JOptionPane.showMessageDialog(parent, "Không thể kết nối cơ sở dữ liệu.");
                return userEmails;
            }
            while (rs.next()) {
                userEmails.add(rs.getString("Email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi khi tải danh sách người dùng: " + e.getMessage());
        }
        return userEmails;
    }

    public List<String> getRoleNames() {
        List<String> roleNames = new ArrayList<>();
        String sql = "SELECT roleName FROM Roles";
        try (Connection conn = Connect.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (conn == null) {
                JOptionPane.showMessageDialog(parent, "Không thể kết nối cơ sở dữ liệu.");
                return roleNames;
            }
            while (rs.next()) {
                roleNames.add(rs.getString("roleName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi khi tải danh sách vai trò: " + e.getMessage());
        }
        return roleNames;
    }

    public void assignRole(String email, String roleName) {
        String taiKhoanID = null;
        String roleID = null;

        // Lấy TaiKhoanID từ Email
        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT TaiKhoanID FROM Users WHERE Email = ?")) {
            if (conn == null) {
                JOptionPane.showMessageDialog(parent, "Không thể kết nối cơ sở dữ liệu.");
                return;
            }
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                taiKhoanID = rs.getString("TaiKhoanID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi khi lấy ID tài khoản: " + e.getMessage());
            return;
        }

        // Lấy roleID từ roleName
        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT roleID FROM Roles WHERE roleName = ?")) {
            if (conn == null) {
                JOptionPane.showMessageDialog(parent, "Không thể kết nối cơ sở dữ liệu.");
                return;
            }
            pstmt.setString(1, roleName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                roleID = rs.getString("roleID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi khi lấy ID vai trò: " + e.getMessage());
            return;
        }

        if (taiKhoanID == null || roleID == null) {
            JOptionPane.showMessageDialog(parent, "Không tìm thấy thông tin tài khoản hoặc vai trò.");
            return;
        }

        // Cập nhật VTID trong bảng Users
        try (Connection conn = Connect.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(parent, "Không thể kết nối cơ sở dữ liệu.");
                return;
            }
            String checkSql = "SELECT VTID FROM Users WHERE TaiKhoanID = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, taiKhoanID);
            ResultSet checkRs = checkStmt.executeQuery();

            String updateSql;
            if (checkRs.next()) { // Đã có vai trò, cập nhật
                updateSql = "UPDATE Users SET VTID = ? WHERE TaiKhoanID = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                    stmt.setString(1, roleID);
                    stmt.setString(2, taiKhoanID);
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(parent, "Cập nhật vai trò thành công!");
                }
            } else {
                JOptionPane.showMessageDialog(parent, "Tài khoản không tồn tại để cập nhật vai trò.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Lỗi khi gán/cập nhật vai trò: " + e.getMessage());
        }
    }
}