/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import poly.cafe.entity.account;
import java.sql.Connection;
import DBCONNEC.Connect;
import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author acchi
 */
public class QLTKdao {
public List<Object[]> getTaiKhoanFull() {
    List<Object[]> list = new ArrayList<>();
    String sql = """
        SELECT tk.TaiKhoanID, tk.Email, tk.TrangThai, tk.VTID, nv.TenNV
        FROM TaiKhoan tk
        LEFT JOIN NhanVien nv ON tk.Email = nv.Email
    """;
    try (Connection con = Connect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            String tkID = rs.getString("TaiKhoanID");
            String email = rs.getString("Email");
            int trangThai = rs.getInt("TrangThai");
            String vtid = rs.getString("VTID");
            String chuSoHuu = rs.getString("TenNV");
            if (chuSoHuu == null) chuSoHuu = "Không xác định";

            String ttText = (trangThai == 1) ? "Còn Hoạt động" : "Đã khóa";

            list.add(new Object[]{tkID, email, ttText, vtid, chuSoHuu});
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}
public String getHinhAnhByTaiKhoan(String taiKhoanID) {
    String sql = """
        SELECT nv.HinhAnh
        FROM TaiKhoan tk
        LEFT JOIN NhanVien nv ON tk.Email = nv.Email
        WHERE tk.TaiKhoanID = ?
    """;
    try (Connection con = Connect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, taiKhoanID);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getString("HinhAnh"); // ✅ trả đúng kiểu Setting
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
private String getVTIDByEmail(String email) {
    String sql = "SELECT VTID FROM TaiKhoan WHERE Email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getString("VTID");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
public boolean doiTrangThaiTaiKhoan(String email, int trangThai) {
    // 1) Lấy VTID
    String vtid = getVTIDByEmail(email);
    // 2) Nếu là ADMIN thì không cho đổi, trả về false
    if ("001".equalsIgnoreCase(vtid)) {
        return false;
    }

    // 3) Còn lại thực hiện update bình thường
    String sql = "UPDATE TaiKhoan SET TrangThai = ? WHERE Email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, trangThai);
        ps.setString(2, email);
        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
public boolean kichHoatTaiKhoan(String email) throws Exception {
        return doiTrangThaiTaiKhoan(email, 1);
    }

    public boolean voHieuHoaTaiKhoan(String email) throws Exception {
        return doiTrangThaiTaiKhoan(email, 0);
    }
    public boolean addTaiKhoan(account acc) {
        String sql = "INSERT INTO TaiKhoan (TaiKhoanID, Email, MatKhau, TrangThai, VTID)"
                   + " VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, acc.getTaiKhoan());
            ps.setString(2, acc.getEmail());
            ps.setString(3, acc.getMatKhau());
            ps.setInt(4, 1);
            ps.setString(5, acc.getVTID());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public String getMatKhauByEmail(String email) {
    String sql = "SELECT Matkhau FROM TaiKhoan WHERE Email = ?";
    try (Connection c = Connect.getConnection();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) return rs.getString("MatKhau");
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}


    public boolean deleteTaiKhoan(String taiKhoanID) {
        String sql = "DELETE FROM taikhoan WHERE TaikhoanID = ?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, taiKhoanID);
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean capQuyenOwner(String taiKhoanID) {
    String sql = "UPDATE taikhoan SET VTID = '000' WHERE TaikhoanID = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, taiKhoanID);
        return ps.executeUpdate() > 0;
    } catch (Exception ex) {
        // log nếu cần
        ex.printStackTrace();
        return false;
    }
}
    public boolean capQuyen(String taiKhoanID, String newVtid) {
        String sql = "UPDATE taikhoan SET VTID = ? WHERE TaikhoanID = ?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newVtid);
            ps.setString(2, taiKhoanID);
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
