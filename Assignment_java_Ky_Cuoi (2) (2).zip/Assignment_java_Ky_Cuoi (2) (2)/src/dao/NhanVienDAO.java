package dao;

import DBCONNEC.Connect;
import poly.cafe.entity.QLNV;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {

    // Hàm lấy tất cả nhân viên
    public List<QLNV> getAll() {
        List<QLNV> list = new ArrayList<>();
        String sql = "SELECT * FROM NhanVien";

        try (Connection conn = Connect.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                QLNV nv = new QLNV();
                nv.setMaNV(rs.getInt("MaNV"));
                nv.setTenNV(rs.getString("TenNV"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setSdt(rs.getString("SDT"));
                nv.setHinhanh(rs.getString("hinhanh"));
                nv.setEmail(rs.getString("email"));
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    
    public boolean kiemTraEmailTonTai(String email, Integer maNV) {
        String sql = "SELECT COUNT(*) FROM NhanVien WHERE email = ?";
        if (maNV != null) {
            sql += " AND MaNV <> ?";
        }

        try (Connection conn = Connect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, email);
            if (maNV != null) {
                pst.setInt(2, maNV);
            }

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    
    public int insert(QLNV nv) {
        
        if (kiemTraEmailTonTai(nv.getEmail(), null)) {
            JOptionPane.showMessageDialog(null, "Email đã tồn tại, không thể thêm mới.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return 0;
        }

        String sql = "INSERT INTO NhanVien (TenNV, GioiTinh, NgaySinh, SDT, hinhanh, email) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, nv.getTenNV());
            pst.setString(2, nv.getGioiTinh());
            pst.setDate(3, nv.getNgaySinh());
            pst.setString(4, nv.getSdt());
            pst.setString(5, nv.getHinhanh());
            pst.setString(6, nv.getEmail());

            return pst.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    
    public int delete(int maNV, String email) throws Exception {
        // chặn khi account active
        if (existsActiveByEmail(email)) {
            JOptionPane.showMessageDialog(
                null,
                "Không thể xóa vì tài khoản với email này đang active.",
                "Thông báo",
                JOptionPane.WARNING_MESSAGE
            );
            return 0;
        }
        // else: xóa bình thường
        String sql = "DELETE FROM NhanVien WHERE MaNV = ?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, maNV);
            return pst.executeUpdate();
        }
    }



    
    public boolean capNhatNhanVien(QLNV nv) throws Exception {
        int maNV    = nv.getMaNV();
        String newEmail = nv.getEmail();

        // Lấy email cũ
        String oldEmail;
        String q = "SELECT email FROM NhanVien WHERE MaNV = ?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(q)) {
            ps.setInt(1, maNV);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(
                        null,
                        "Không tìm thấy nhân viên mã " + maNV,
                        "Lỗi",
                        JOptionPane.WARNING_MESSAGE
                    );
                    return false;
                }
                oldEmail = rs.getString("email");
            }
        }

        // Nếu email cũ đang active → chặn toàn bộ update (dù chỉ đổi ảnh hay đổi info)
        if (existsActiveByEmail(oldEmail)) {
            JOptionPane.showMessageDialog(
                null,
                "Không thể cập nhật vì tài khoản với email cũ đang active.",
                "Thông báo",
                JOptionPane.WARNING_MESSAGE
            );
            return false;
        }

        // Nếu cần thêm check trùng email mới với nhân viên khác thì giữ như cũ:
        if (kiemTraEmailTonTai(newEmail, maNV)) {
            JOptionPane.showMessageDialog(
                null,
                "Email mới đã tồn tại, không thể cập nhật.",
                "Thông báo",
                JOptionPane.WARNING_MESSAGE
            );
            return false;
        }

        // Thực hiện UPDATE
        String sql = "UPDATE NhanVien "
                   + "SET TenNV=?, GioiTinh=?, NgaySinh=?, SDT=?, HinhAnh=?, email=? "
                   + "WHERE MaNV=?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nv.getTenNV());
            ps.setString(2, nv.getGioiTinh());
            ps.setDate(3, nv.getNgaySinh());
            ps.setString(4, nv.getSdt());
            ps.setString(5, nv.getHinhanh());
            ps.setString(6, newEmail);
            ps.setInt(7, maNV);
            return ps.executeUpdate() > 0;
        }
    }

    
    public List<QLNV> timKiemNhanVienTheoTen(String keyword) {
        List<QLNV> list = new ArrayList<>();
        String sql = "SELECT * FROM NhanVien WHERE TenNV LIKE ?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, "%" + keyword + "%");
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                QLNV nv = new QLNV();
                nv.setMaNV(rs.getInt("MaNV"));
                nv.setTenNV(rs.getString("TenNV"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setSdt(rs.getString("SDT"));
                nv.setHinhanh(rs.getString("hinhanh"));
                nv.setEmail(rs.getString("email"));
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public QLNV getByEmail(String email) {
    String sql = "SELECT * FROM NhanVien WHERE email = ?";
    QLNV nv = null;

    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                nv = new QLNV();
                nv.setMaNV(rs.getInt("MaNV"));
                nv.setTenNV(rs.getString("TenNV"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setSdt(rs.getString("SDT"));
                nv.setHinhanh(rs.getString("hinhanh"));
                nv.setEmail(rs.getString("email"));
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return nv;
}
    public boolean capNhatAnhNhanVien(String email, String hinhAnh) {
    String sql = "UPDATE NhanVien SET hinhanh = ? WHERE email = ?";

    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, hinhAnh);
        ps.setString(2, email);

        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
    // Trong AccountDAO (hoặc DAO mà bạn dùng để thao tác bảng taikhoan)
public boolean existsActiveByEmail(String email) throws Exception {
        String sql = "SELECT 1 FROM taikhoan WHERE Email = ? AND trangthai = 1";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}