/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;


import DBCONNEC.Connect;
import java.util.ArrayList;
import java.util.List;
import poly.cafe.entity.Doanhthuenity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import poly.cafe.entity.PMHModel;
import poly.cafe.entity.Sanpham;
import poly.cafe.entity.ThongkeNV;

public class Thongkedao {

    // 1. Doanh thu theo sản phẩm (có lọc theo ngày)
    public List<Doanhthuenity> getDoanhThuTheoSanPham(LocalDate from, LocalDate to) {
        List<Doanhthuenity> list = new ArrayList<>();
        String sql = "SELECT MaSp, TenSP, LoaiSP, SUM(Gia * SoLuong) AS DoanhThu " +
                     "FROM Chitietphieu ct JOIN PhieuMuaHang p ON ct.MaHD = p.MaHD " +
                     "WHERE p.NgayLap BETWEEN ? AND ? AND p.DaThanhToan = 1 AND p.DaHuy = 0 " +
                     "GROUP BY TenSP, LoaiSP, MaSp";

        try (Connection conn = Connect.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, java.sql.Date.valueOf(from));
            stmt.setDate(2, java.sql.Date.valueOf(to));

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String maSP = rs.getString("MaSp");
                String tenSP = rs.getString("TenSP");
                String loaiSP = rs.getString("LoaiSP");
                long doanhThu = rs.getLong("DoanhThu");

                Doanhthuenity dt = new Doanhthuenity(maSP, tenSP, loaiSP, doanhThu);
                list.add(dt);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 2. Doanh thu nhân viên (tổng, không lọc)
    public List<ThongkeNV> getDoanhThuNhanVien() {
        List<ThongkeNV> list = new ArrayList<>();
        String sql = "SELECT TenNV, SUM(TongTien) AS DoanhThu, MAX(NgayLap) AS Ngay " +
                     "FROM PhieuMuaHang " +
                     "WHERE DaThanhToan = 1 AND DaHuy = 0 " +
                     "GROUP BY TenNV ORDER BY DoanhThu DESC";

        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ThongkeNV nv = new ThongkeNV();
                nv.setTenNV(rs.getString("TenNV"));
                nv.setTongTien(rs.getDouble("DoanhThu"));
                nv.setNgay(rs.getDate("Ngay"));
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 3. Doanh thu nhân viên theo ngày
    public List<ThongkeNV> getDoanhThuNhanVienTheoNgay(LocalDate from, LocalDate to) {
        List<ThongkeNV> list = new ArrayList<>();
        String sql = "SELECT TenNV, SUM(TongTien) AS DoanhThu, MAX(NGAYLAP) AS Ngay " +
                     "FROM PhieuMuaHang " +
                     "WHERE DaThanhToan = 1 AND DaHuy = 0 AND NGAYLAP BETWEEN ? AND ? " +
                     "GROUP BY TenNV ORDER BY DoanhThu DESC";

        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, java.sql.Date.valueOf(from));
            ps.setDate(2, java.sql.Date.valueOf(to));

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ThongkeNV nv = new ThongkeNV();
                nv.setTenNV(rs.getString("TenNV"));
                nv.setTongTien(rs.getDouble("DoanhThu"));
                nv.setNgay(rs.getDate("Ngay"));
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}



