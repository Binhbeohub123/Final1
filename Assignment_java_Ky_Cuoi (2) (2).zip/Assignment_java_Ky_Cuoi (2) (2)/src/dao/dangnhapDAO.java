
package dao;

import DBCONNEC.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import poly.cafe.entity.account;

public class dangnhapDAO {
    public account findUser(String taiKhoanID) throws SQLException {
    String sql = "SELECT Matkhau, VTID, TrangThai, Email"
               + "  FROM taikhoan "
               + " WHERE TaikhoanID = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, taiKhoanID);
        try (ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) return null;
            String dbPass      = rs.getString("Matkhau");
            String role        = rs.getString("VTID");
            boolean trangThai  = rs.getBoolean("TrangThai");
            String email       = rs.getString("Email");
            return new account(taiKhoanID, dbPass, role, trangThai, email);
        }
    }
}
}
