/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import DBCONNEC.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import poly.cafe.entity.PendingAccount;

/**
 *
 * @author acchi
 */
public class DangkyDao {
    public Boolean CheckUserExist(String Email) {
    String sql = "SELECT * FROM taikhoan WHERE Email = ?";
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        if (connection == null) {
            throw new SQLException("Không thể kết nối đến cơ sở dữ liệu.");
        }
        ps.setString(1, Email);
        try (ResultSet rs = ps.executeQuery()) {
            return rs.next();
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi kiểm tra tài khoản: " + e.getMessage());
        e.printStackTrace();
        return false;
        }
    }
    public boolean Insert(String TaikhoanID, String MatKhau, String Email) {
    // Biến để lưu VTID
    String VTID;

    // SQL đếm tài khoản
    String countSql    = "SELECT COUNT(*) AS total FROM taikhoan";
    // SQL kiểm tra email
    String checkSql    = "SELECT COUNT(*) AS total FROM taikhoan WHERE Email = ?";
    // SQL INSERT giờ có thêm cột TrangThai (mặc định 1)
    String insertSql   = "INSERT INTO taikhoan (TaikhoanID, Matkhau, Email, VTID, trangthai) "
                       + "VALUES (?, ?, ?, ?, ?)";

    try (Connection connection = Connect.getConnection()) {
        if (connection == null) throw new SQLException("Không thể kết nối đến cơ sở dữ liệu.");

        // 1) Đếm tài khoản để gán VTID
        try (PreparedStatement countPs = connection.prepareStatement(countSql);
             ResultSet countRs = countPs.executeQuery()) {
            if (countRs.next()) {
                int totalAccounts = countRs.getInt("total");
                VTID = (totalAccounts == 0) ? "000" : "002";
            } else {
                throw new SQLException("Không thể đếm số lượng tài khoản.");
            }
        }

        // 2) Kiểm tra email đã tồn tại?
        try (PreparedStatement checkPs = connection.prepareStatement(checkSql)) {
            checkPs.setString(1, Email);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next() && rs.getInt("total") > 0) {
                    // Email đã tồn tại → trả về true (hoặc false tuỳ logic của bạn)
                    return true;
                }
            }
        }

        // 3) Thực hiện INSERT, gán TrangThai = 1
        try (PreparedStatement insertPs = connection.prepareStatement(insertSql)) {
            insertPs.setString(1, TaikhoanID);
            insertPs.setString(2, MatKhau);
            insertPs.setString(3, Email);
            insertPs.setString(4, VTID);
            insertPs.setInt   (5, 1);      // TRANGTHAI = 1
            int rows = insertPs.executeUpdate();
            return rows > 0;
        }

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
    public static boolean insertPending(PendingAccount acc) {
    String sql = "INSERT INTO PendingAccount (taikhoanID, password, confirmPassword, email) VALUES (?, ?, ?, ?)";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, acc.getTaikhoanID());
        ps.setString(2, acc.getPassword());
        ps.setString(3, acc.getConfirmPassword());
        ps.setString(4, acc.getEmail());
        int rowsAffected = ps.executeUpdate();
        System.out.println("Insert pending account for email " + acc.getEmail() + ": " + (rowsAffected > 0));
        return rowsAffected > 0; // Trả về true nếu có dòng được insert

    } catch (SQLException e) {
        System.err.println("Lỗi khi insert pending account cho email " + acc.getEmail() + ": " + e.getMessage());
        e.printStackTrace();
        return false; // Trả về false nếu có lỗi
    }
}
    public static String getTenByEmail(String email) {
    String sql = "SELECT taikhoanID FROM PendingAccount WHERE email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getString("taikhoanID");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    public static PendingAccount findByEmail(String email) {
    String sql = "SELECT * FROM PendingAccount WHERE email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return new PendingAccount(
                rs.getString("taikhoanID"),
                rs.getString("password"),
                rs.getString("confirmPassword"),
                rs.getString("email")
            );
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    public static void deleteByEmail(String email) {
    String sql = "DELETE FROM PendingAccount WHERE email = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ps.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    public static boolean confirmAndInsertAccount(String email) {
    // Lấy account tạm từ bảng PendingAccount
    PendingAccount acc = findByEmail(email);
    if (acc == null) {
        System.err.println("Không tìm thấy tài khoản tạm thời với email: " + email);
        return false;
    }

    // Kiểm tra nếu tài khoản đã tồn tại trong bảng chính thì không insert nữa
    if (new DangkyDao().CheckUserExist(email)) {
        System.err.println("Tài khoản với email đã tồn tại: " + email);
        return false;
    }

    // Insert vào bảng chính
    boolean inserted = new DangkyDao().Insert(
        acc.getTaikhoanID(),
        acc.getPassword(),
        acc.getEmail()
    );

    // Nếu insert thành công, xóa tài khoản tạm
    if (inserted) {
        deleteByEmail(email);
        return true;
    }

    return false;
}
    public boolean isEmailInNhanSu(String email) {
    boolean found = false;

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        conn = Connect.getConnection();
        String sql = "SELECT * FROM NhanVien WHERE email = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, email);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            found = true;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return found;
}
    public Boolean CheckUsernameExist(String TaikhoanID) {
    String sql = "SELECT * FROM taikhoan WHERE TaikhoanID = ?";
    try (Connection connection = Connect.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        if (connection == null) {
            throw new SQLException("Không thể kết nối đến cơ sở dữ liệu.");
        }
        ps.setString(1, TaikhoanID);
        try (ResultSet rs = ps.executeQuery()) {
            return rs.next(); // true nếu tồn tại, false nếu chưa
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi kiểm tra tên tài khoản: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}
    public static int soLuongTaiKhoan() {
    String sql = "SELECT COUNT(*) FROM taikhoan";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}
}
