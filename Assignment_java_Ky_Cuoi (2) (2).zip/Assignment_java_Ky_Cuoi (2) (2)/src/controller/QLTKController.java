package controller;

import dao.QLTKdao;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import poly.cafe.entity.account;
import dao.DangkyDao;


public class QLTKController {
    private final QLTKdao dao = new QLTKdao();
    private final DangkyDao dao2 = new DangkyDao();
    private JTable tblTaiKhoan;
    
    public QLTKController() {
        // tblTaiKhoan không dùng ở createAccount nên để null là được
    }

    public QLTKController(JTable tblTaiKhoan) {
        this.tblTaiKhoan = tblTaiKhoan;
    }

    public List<Object[]> getTaiKhoanFull() {
        return dao.getTaiKhoanFull();
    }


    public String getHinhAnhByTaiKhoan(String taiKhoanID) {
        return dao.getHinhAnhByTaiKhoan(taiKhoanID);
    }

    public void loadTaiKhoanToTable() {
        DefaultTableModel model = (DefaultTableModel) tblTaiKhoan.getModel();
        model.setRowCount(0);
        List<Object[]> list = dao.getTaiKhoanFull();
        for (Object[] row : list) {
            model.addRow(row);
        }
    }


    public boolean kichHoatTaiKhoan(String email) {
        try {
            return dao.kichHoatTaiKhoan(email);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean voHieuHoaTaiKhoan(String email) {
    try {
        return dao.voHieuHoaTaiKhoan(email);
    } catch (IllegalArgumentException iae) {
        // Đây là thông báo "Không thể khóa hoặc kích hoạt lại tài khoản Admin!"
        JOptionPane.showMessageDialog(null,
            iae.getMessage(),
            "Không cho phép",
            JOptionPane.WARNING_MESSAGE);
        return false;
    } catch (Exception e) {
        // Các lỗi bất ngờ khác
        JOptionPane.showMessageDialog(null,
            "Có lỗi khi vô hiệu hóa tài khoản:\n" + e.getMessage(),
            "Lỗi",
            JOptionPane.ERROR_MESSAGE);
        return false;
    }
}
    
    public boolean createAccount(account acc) {
        // 1) Kiểm tra email có trong bảng NhanVien
        if (!dao2.isEmailInNhanSu(acc.getEmail())) {
            JOptionPane.showMessageDialog(null,
                "Email này không tồn tại trong danh sách nhân sự. Không thể tạo tài khoản.",
                "Lỗi thêm tài khoản",
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        // 2) Thực hiện thêm tài khoản
        boolean ok = dao.addTaiKhoan(acc);
        if (!ok) {
            JOptionPane.showMessageDialog(null,
                "Đã xảy ra lỗi khi lưu tài khoản. Vui lòng thử lại.",
                "Lỗi",
                JOptionPane.ERROR_MESSAGE);
        }
        return ok;
    }
public String getMatKhauByEmail(String email) {
    return new QLTKdao().getMatKhauByEmail(email);
}
public boolean xoaTaiKhoan(String taiKhoanID) {
        try {
            boolean ok = dao.deleteTaiKhoan(taiKhoanID);
            if (!ok) {
                // DAO trả về false khi không có hàng nào bị xóa
                JOptionPane.showMessageDialog(null,
                    "Không tìm thấy tài khoản để xóa!",
                    "Lỗi", JOptionPane.WARNING_MESSAGE);
            }
            return ok;
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Lỗi khi xóa tài khoản:\n" + ex.getMessage(),
                "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }


    public boolean xoaTaiKhoanWithHeir(String taiKhoanID, String heirTaiKhoanID) {
        try {
            // 1) Cấp quyền Owner (VTID = '000') cho người thừa kế
            boolean capOwnerOk = dao.capQuyenOwner(heirTaiKhoanID);
            if (!capOwnerOk) {
                JOptionPane.showMessageDialog(null,
                    "Không chuyển được quyền Owner cho người thừa kế!",
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            // 2) Xóa tài khoản gốc
            boolean deleteOk = dao.deleteTaiKhoan(taiKhoanID);
            if (!deleteOk) {
                JOptionPane.showMessageDialog(null,
                    "Xóa tài khoản không thành công!",
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
            return deleteOk;

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Lỗi khi xóa tài khoản với thừa kế:\n" + ex.getMessage(),
                "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    public boolean capQuyen(String taiKhoanID, String newVtid) {
        // 1) Tìm VTID cũ
        String oldVtid = null;
        for (Object[] rec : getTaiKhoanFull()) {
            if (taiKhoanID.equals(rec[0])) {
                oldVtid = rec[3].toString();
                break;
            }
        }
        // 2) Nếu cũ là Owner thì không cho đổi
        if ("000".equals(oldVtid)) {
            return false;
        }
        // 3) Nếu new là Owner thì không cho đổi
        if ("000".equals(newVtid)) {
            return false;
        }
        // 4) Nếu new không phải 001 hoặc 002 thì cũng từ chối
        if (!"001".equals(newVtid) && !"002".equals(newVtid)) {
            return false;
        }
        // 5) Gọi DAO để update
        return dao.capQuyen(taiKhoanID, newVtid);
    }
}