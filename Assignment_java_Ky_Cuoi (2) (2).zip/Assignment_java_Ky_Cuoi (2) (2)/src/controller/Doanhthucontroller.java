/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.Thongkedao;
import giaodien.Thongke;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import poly.cafe.entity.Doanhthuenity;
import poly.cafe.entity.ThongkeNV;


/**
 *
 * @author NTL
 */
public class Doanhthucontroller {
   private Thongkedao doanhThudao = new Thongkedao();

    public Doanhthucontroller() {
        this.doanhThudao = new Thongkedao();
    }

    // Trả về danh sách thay vì gọi view
    public List<Doanhthuenity> getDoanhThuTheoSanPham(LocalDate from, LocalDate to) {
        return doanhThudao.getDoanhThuTheoSanPham(from, to);
    }

    // Đã bỏ tham số ngày

    public List<ThongkeNV> getDoanhThuTheoNhanVien() {
    return doanhThudao.getDoanhThuNhanVien(); // gọi đúng DAO
}
    

public List<ThongkeNV> getDoanhThuNhanVienTheoNgay(LocalDate from, LocalDate to) {
    return doanhThudao.getDoanhThuNhanVienTheoNgay(from, to);
}

}