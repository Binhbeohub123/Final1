package controller;

import dao.daosetting;
import poly.cafe.entity.account;

public class SettingController {
    private daosetting taiKhoanDAO;

    public SettingController() {
        taiKhoanDAO = new daosetting();
    }


    public account layThongTinTaiKhoan(String userID) {
        return taiKhoanDAO.getTaiKhoanByID(userID);
    }
    public boolean doiMatKhau(String email, String matKhauMoi) {
    return taiKhoanDAO.updateMatKhauByEmail(email, matKhauMoi);
}
    public boolean kiemTraMatKhauCu(String email, String nhapTuNguoiDung) {
    String mkHienTai = taiKhoanDAO.getMatKhauByEmail(email);
    return mkHienTai != null && mkHienTai.equals(nhapTuNguoiDung);
}
}