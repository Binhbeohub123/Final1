package controller;

import dao.DangkyDao;
import dao.thaydoimatkhauDAO;
import giaodien.MaXacNhan;
import javax.swing.JOptionPane;
import otpRandom.guiMailMaOTP;
import giaodien.dangkyform;
import dao.Maxacnhandao;
import giaodien.home;
import java.awt.Component;

    
public class MaXacNhanController {
    private MaXacNhan view;
    private thaydoimatkhauDAO dao;
    private guiMailMaOTP otpService;
    private DangkyDao dao2;
    private Maxacnhandao dao3;

    public MaXacNhanController(MaXacNhan view) {
        this.view = view;
        this.dao = new thaydoimatkhauDAO();
        this.dao2 = new DangkyDao();
        this.dao3 = new Maxacnhandao(); // ✅ dùng lại dao3
        this.otpService = new guiMailMaOTP();
    }

   public void sendOTP(String emailInput) {
    int action = view.getActionType();

    try {
        // LUỒNG ĐỔI MAIL BỞI ADMIN
        if (action == MaXacNhan.ACTION_CHANGE_EMAIL_BY_ADMIN) {
            // 1) Lấy email mới admin vừa nhập
            String newEmail  = view.getTextField1();    // giả sử bạn có getter này
            String oldEmail  = view.getTargetEmail(); // email user cũ

            // 2) Kiểm tra định dạng và đã dùng chưa
            if (newEmail == null || !isValidEmail(newEmail)) {
                JOptionPane.showMessageDialog(view, "Email mới không hợp lệ!");
                return;
            }
            if (dao3.isEmailUsedByOthers(newEmail, oldEmail)) {
                JOptionPane.showMessageDialog(view, "Email mới đã được sử dụng.");
                return;
            }

            // 3) Gửi OTP về adminEmail
            otpService.guiEmailOTP(view, view.getAdminEmail(), action);
            JOptionPane.showMessageDialog(view,
                "Mã xác nhận đã được gửi đến quản trị viên: " + view.getAdminEmail());
            return;
        }

        // LUỒNG ĐỔI MAIL BÌNH THƯỜNG CỦA USER
        else if (action == MaXacNhan.ACTION_CHANGE_EMAIL) {
            String emailCu = view.getEmail();
            if (dao3.isEmailUsedByOthers(emailInput, emailCu)) {
                JOptionPane.showMessageDialog(view, "Email mới đã được sử dụng.");
                return;
            }
            emailInput = emailCu;  // gửi OTP về email cũ
        }

        // LUỒNG RESET PASSWORD
        else if (action == MaXacNhan.ACTION_RESET_PASSWORD) {
            if (!dao.checkUserCredentials(emailInput)) {
                JOptionPane.showMessageDialog(view, "Email chưa đăng ký!");
                return;
            }
        }

        // LUỒNG REGISTER
        else if (action == MaXacNhan.ACTION_REGISTER) {
            if (dao.checkUserCredentials(emailInput)) {
                JOptionPane.showMessageDialog(view, "Email đã tồn tại!");
                return;
            }
        }

        // Gửi OTP cho 3 luồng trên
        otpService.guiEmailOTP(view, emailInput, action);
        JOptionPane.showMessageDialog(view, "Mã OTP đã được gửi đến: " + emailInput);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(view, "Lỗi gửi OTP: " + ex.getMessage());
    }
}

    public boolean xacNhanOTP(String email, String otp, int action) {
        Maxacnhandao dao = new Maxacnhandao();
        if (action == MaXacNhan.ACTION_CHANGE_EMAIL_BY_ADMIN || action == MaXacNhan.ACTION_RESET_PASSWORD
         || action == MaXacNhan.ACTION_CHANGE_EMAIL) {
            return dao.checkOTP(email, otp);
        } else {
            return dao.checkOTPpending(email, otp);
        }
    }

    public void backToLogin() {
        if (view.getParentFrame().getPanelGoc() != null) {
            view.getParentFrame().setContentPane(view.getParentFrame().getPanelGoc());
            view.getParentFrame().revalidate();
            view.getParentFrame().repaint();
        } else {
            JOptionPane.showMessageDialog(view, "Không thể tải giao diện đăng nhập!");
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email != null && email.matches(emailRegex);
    }

    public boolean doiEmail(String emailCu, String emailMoi) {
        return dao3.updateEmail(emailCu, emailMoi); // ✅ dùng dao3
    }

    public boolean isEmailUsedByOthers(String newEmail, String oldEmail) {
        return dao3.isEmailUsedByOthers(newEmail, oldEmail); // ✅ dùng dao3
    }
}
 
