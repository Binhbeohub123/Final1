package controller;

import XAuthen.XAuthen;
import dao.dangnhapDAO;
import javax.swing.JOptionPane;
import poly.cafe.entity.account;

public class dangnhapController {

    private dangnhapDAO dao;
    private int lanDangNhap = 0;
    private static final int gioiHanLanDangNhap = 5;

    public dangnhapController() {
        this.dao = new dangnhapDAO();
    }

    public boolean login(String username, String password) {
        try {
            // 1) Lấy account từ DAO (chỉ 1 query)
            account acc = dao.findUser(username);
            if (acc == null) {
                JOptionPane.showMessageDialog(null,
                    "Tên đăng nhập hoặc mật khẩu không đúng.",
                    "Đăng nhập thất bại",
                    JOptionPane.WARNING_MESSAGE);
                return false;
            }

            // 2) Kiểm tra mật khẩu
            if (!acc.getMatKhau().equals(password)) {
                JOptionPane.showMessageDialog(null,
                    "Tên đăng nhập hoặc mật khẩu không đúng.",
                    "Đăng nhập thất bại",
                    JOptionPane.WARNING_MESSAGE);
                return false;
            }

            // 3) Kiểm tra trạng thái account
            if (!acc.isTrangthai()) {
                JOptionPane.showMessageDialog(null,
                    "Tài khoản của bạn đang bị khóa.",
                    "Tài khoản bị khóa",
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }

            // 4) Thành công: gán user + role vào XAuthen
            XAuthen.currentUser = acc.getTaiKhoan();
            XAuthen.RoleUser    = acc.getVTID();
            XAuthen.Email = acc.getEmail();
            return true;

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,
                "Lỗi kết nối cơ sở dữ liệu.",
                "Lỗi",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
            return false;
        }
    }

    // ✅ Hàm xử lý chuỗi viết trực tiếp trong controller
    private boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }
}
