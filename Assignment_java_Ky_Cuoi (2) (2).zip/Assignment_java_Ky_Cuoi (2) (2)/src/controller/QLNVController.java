package controller;

import dao.NhanVienDAO;
import java.util.List;
import javax.swing.JOptionPane;
import poly.cafe.entity.QLNV;

public class QLNVController {
    private final NhanVienDAO dao = new NhanVienDAO();

    public List<QLNV> layDanhSachNhanVien() {
        return dao.getAll();
    }

    public boolean themNhanVien(QLNV nv) {
        return dao.insert(nv) > 0;
    }

    // Không throws nữa, tự catch
    public boolean xoaNhanVien(int maNV, String email) {
        try {
            return dao.delete(maNV, email) > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Lỗi khi xóa nhân viên: " + ex.getMessage(),
                "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // Không throws nữa
    public boolean capNhatNhanVien(QLNV nv) {
        try {
            return dao.capNhatNhanVien(nv);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Lỗi khi cập nhật nhân viên: " + ex.getMessage(),
                "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public List<QLNV> timKiemNhanVien(String keyword) {
        return dao.timKiemNhanVienTheoTen(keyword);
    }

    public QLNV getNhanVienByEmail(String email) {
        return dao.getByEmail(email);
    }

    // Bỏ throws, tự catch
    public boolean capNhatAnhTheoEmail(String email, String duongDanAnh) {
        try {
            return dao.capNhatAnhNhanVien(email, duongDanAnh);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Lỗi khi cập nhật ảnh nhân viên: " + ex.getMessage(),
                "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}