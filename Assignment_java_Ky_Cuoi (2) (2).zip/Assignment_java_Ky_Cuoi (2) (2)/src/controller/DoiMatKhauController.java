package controller;

import dao.thaydoimatkhauDAO;
import javax.swing.JOptionPane;

public class DoiMatKhauController {
    private final thaydoimatkhauDAO dao;

    public DoiMatKhauController() {
        this.dao = new thaydoimatkhauDAO();
    }


    public boolean changePassword(String email, String newPass, String rePass) {
        // 1. Kiểm tra rỗng
        if (newPass.isEmpty() || rePass.isEmpty()) {
            throw new IllegalArgumentException("Vui lòng nhập đầy đủ mật khẩu!");
        }
        // 2. Kiểm tra khớp
        if (!newPass.equals(rePass)) {
            throw new IllegalArgumentException("Mật khẩu xác nhận không khớp!");
        }
        // 3. Gọi DAO
        return dao.updatePassword(email, newPass);
    }
}
