package Base64;

import java.util.Base64;
import java.util.UUID;

public class Base64Example {
    public static String generateVerificationCode(String userName) {
        // Tạo UUID ngẫu nhiên
        UUID uuid = UUID.randomUUID();
        
        // Tạo chuỗi kết hợp UUID và tên người dùng
        String combinedString = userName + ":" + uuid.toString();
        
        // Mã hóa chuỗi kết hợp (tên người dùng và UUID) thành Base64
        String encoded = Base64.getEncoder().encodeToString(combinedString.getBytes());
        
        // Trả về mã xác nhận (mã hóa Base64 của tên người dùng và UUID)
        return encoded;
    }
}
