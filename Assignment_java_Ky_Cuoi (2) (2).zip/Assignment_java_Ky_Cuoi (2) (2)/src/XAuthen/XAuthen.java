 
package XAuthen;
 
import giaodien.home;

public class XAuthen {
     // Biến static để lưu user đang đăng nhập hiện tại (account là tên class model user)
    public static String currentUser = null;
    public static String RoleUser = null;
    public static String Email = null;

    // Đăng xuất (clear user)
    public static boolean clear() {
        currentUser = null;
        RoleUser = null;
        Email = null;
         return currentUser == null && RoleUser == null && Email == null;
    }

    // Kiểm tra đã đăng nhập chưa
    public static boolean isLogin() {
        home.role = RoleUser;
        return currentUser != null && RoleUser != null && Email != null;
    }

}
