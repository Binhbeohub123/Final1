
package giaodien;

import dao.QLTKdao;
import giaodien.home;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import XAuthen.XAuthen;
import controller.QLTKController;
import java.awt.Dialog;
import java.awt.Image;
import java.awt.MediaTracker;
import java.io.File;
import javaswingdev.NotificationManager;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class formgoc extends javax.swing.JPanel {

private final QLTKController controller;

    public formgoc() {
        initComponents();
        loadTaiKhoan();
        this.controller = new QLTKController(table);
        jButton2.setVisible(false);
        jButton8.setVisible(false);
        jButton6.setVisible(false);
        table.getSelectionModel().addListSelectionListener(e -> {
    // tránh xử lý hai lần, chỉ khi đã ổn định thay đổi
    if (!e.getValueIsAdjusting()) {
        boolean hasSelection = table.getSelectedRow() != -1;
        jButton8.setVisible(hasSelection);
        jButton6.setVisible(hasSelection);
    }
});
        cbRole.addItem("000: Owner");
        cbRole.addItem("001: Admin");
        cbRole.addItem("002: User");
    }
    public void loadTaiKhoan() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(0); // Xóa dữ liệu cũ

    QLTKdao dao = new QLTKdao();
    List<Object[]> list = dao.getTaiKhoanFull();

    String currentUser = XAuthen.currentUser;

    for (Object[] row : list) {
        String taiKhoanID = (String) row[0];
        String email = (String) row[1];
        String trangThai = (String) row[2];
        String vtid = (String) row[3];
        String chuSoHuu = (String) row[4];

        // Đổi mã quyền thành tên
        String roleName;
        switch (vtid) {
            case "000":
                roleName = "ONWER";
                break;
            case "001":
                roleName = "Admin";
                break;
            case "002":
                roleName = "User";
                break;
                
            default:
                roleName = "Không xác định";
                break;
        }

        if (taiKhoanID.equalsIgnoreCase(currentUser)) {
            chuSoHuu += " (Đang sử dụng)";
        }

        // KHÔNG add ảnh vào bảng!
        model.addRow(new Object[]{taiKhoanID, email, roleName, chuSoHuu, trangThai});
    }
    
}
    private void hienThiAnh(String path, javax.swing.JLabel label) {
    if (path == null || path.trim().isEmpty()) {
        label.setText("[Không có ảnh]");
        label.setIcon(null);
        return;
    }

    File file = new File(path);
    if (!file.exists()) {
        label.setText("[Ảnh không tồn tại]");
        label.setIcon(null);
        return;
    }

    ImageIcon icon = new ImageIcon(file.getAbsolutePath());
    if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
        int width = label.getWidth() > 0 ? label.getWidth() : 318;
        int height = label.getHeight() > 0 ? label.getHeight() : 255;
        Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        label.setIcon(new ImageIcon(img));
        label.setText("");
    } else {
        label.setText("[Không thể tải ảnh]");
        label.setIcon(null);
    }
}
    private void toggleAccountStatus() {
    int row = table.getSelectedRow();
    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một tài khoản.");
        return;
    }

    String email      = table.getValueAt(row, 1).toString();
    String statusText = table.getValueAt(row, 4).toString();

    // 0) Dùng getTaiKhoanFull để tìm VTID của email này
    String vtid = "";
    for (Object[] record : controller.getTaiKhoanFull()) {
        if (email.equals(record[1])) {       // record[1] là Email
            vtid = record[3].toString();     // record[3] là VTID
            break;
        }
    }
    // 1) Chặn Admin
    if ("000".equalsIgnoreCase(vtid)) {
        JOptionPane.showMessageDialog(this,
            "Không thể khóa hoặc kích hoạt lại tài khoản Admin!",
            "Không cho phép",
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    // 2) Tiếp tục logic cũ
    boolean success;
    String action;
    if ("Đã khóa".equals(statusText)) {
        success = controller.kichHoatTaiKhoan(email);
        action  = "mở lại";
    } else if ("Còn Hoạt động".equals(statusText)) {
        success = controller.voHieuHoaTaiKhoan(email);
        action  = "khóa";
    } else {
        JOptionPane.showMessageDialog(this, "Không thể xác định trạng thái để đổi.");
        return;
    }

    if (success) {
        JOptionPane.showMessageDialog(this,
            "Đã " + action + " tài khoản thành công!");
        loadTaiKhoan();
    } else {
        JOptionPane.showMessageDialog(this,
            "Thao tác " + action + " thất bại.",
            "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
}
    private void moFormThemTK() {
    // Lấy cửa sổ cha (có thể là JFrame hoặc JDialog) của panel formgoc
    java.awt.Window owner = SwingUtilities.getWindowAncestor(this);
    
    // Tạo JDialog modal
    JDialog dialog = new JDialog(owner, "Thêm Tài Khoản", Dialog.ModalityType.APPLICATION_MODAL);
    dialog.setUndecorated(true);

    // Tạo instance form thêm TK, có thể truyền controller nếu cần
    ThemTK form = new ThemTK();
    dialog.setContentPane(form);
    dialog.pack();
    
    
    
    // Căn giữa relative to this panel
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);

    // Sau khi dialog đóng, làm mới lại bảng
    loadTaiKhoan();
}
    private void moFormDoiMatKhau(String email, String currentPassword) {
    java.awt.Window owner = SwingUtilities.getWindowAncestor(this);
    JDialog dialog = new JDialog(owner, "Đổi Mật Khẩu", Dialog.ModalityType.APPLICATION_MODAL);
    dialog.setUndecorated(true);

    Doimatin panel = new Doimatin(email);
    panel.Matkhaunow.setText(currentPassword);
    panel.Matkhaunow.setEchoChar('•');
    panel.Matkhaunow.setEnabled(false);

    dialog.setContentPane(panel);
    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);

    loadTaiKhoan(); // nếu cần refresh
}

    private void moFormDoiEmail(String targetEmail, String adminEmail) {
    // Lấy cửa sổ cha (có thể là JFrame hoặc JDialog) của panel hiện tại
    java.awt.Window owner = SwingUtilities.getWindowAncestor(this);

    // Tạo JDialog modal
    JDialog dialog = new JDialog(owner, "Xác nhận Đổi Gmail", Dialog.ModalityType.APPLICATION_MODAL);
    dialog.setUndecorated(true);

    // Khởi panel với đúng actionType
    MaXacNhan panel = new MaXacNhan(
        targetEmail,
        adminEmail,
        MaXacNhan.ACTION_CHANGE_EMAIL_BY_ADMIN
    );

    dialog.setContentPane(panel);
    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);

    // Sau khi đóng dialog, làm mới bảng
    loadTaiKhoan();
}
    
    public void clearform() {
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField5.setText("");
    jTextField6.setText("");

    // GIỮ combobox nếu chủ ý muốn hiển thị Owner
    // cbRole.setSelectedIndex(-1);
    cbRole.setEnabled(false);

    jButton2.setVisible(false);
    jButton6.setVisible(false);
    jButton8.setVisible(false);

    lbanh.setIcon(null);
    lbanh.setText("");

    table.clearSelection();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lbanh = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        cbRole = new javax.swing.JComboBox<>();

        setBackground(new java.awt.Color(176, 236, 188));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(176, 236, 188));

        table.setBackground(new java.awt.Color(176, 236, 188));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Tên Tài Khoản", "Email", "Quyền Hạn", "Chủ Sở Hữu", "Trạng Thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        jButton4.setText("Xóa");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Thêm");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setText("Tìm kiếm .....");
        jTextField1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField1.setCaretColor(new java.awt.Color(204, 204, 204));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Tìm kiếm");

        jButton3.setText("Làm mới");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton6.setText("Đổi Gmail");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton8.setText("Đổi Mật Khẩu");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 891, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addComponent(jScrollPane1))
                .addGap(92, 92, 92))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5)
                    .addComponent(jButton4)
                    .addComponent(jButton3)
                    .addComponent(jButton6)
                    .addComponent(jButton8))
                .addGap(9, 9, 9))
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 1000, 690));

        jPanel3.setBackground(new java.awt.Color(176, 236, 188));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Email");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 300, -1));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 260, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Tên Tài Khoản");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 300, -1));

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 260, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Quyền Hạn");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 520, 300, -1));

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 630, 260, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Chủ sở hữu");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 600, 300, -1));

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbanh, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbanh, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 190));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Thông Tin");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 630, 260, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Chủ sở hữu");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 600, 300, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Trạng Thái");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 670, 300, -1));

        jButton2.setText("Text");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 700, 120, -1));

        cbRole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRoleActionPerformed(evt);
            }
        });
        jPanel3.add(cbRole, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 560, 160, -1));

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 0, 300, 730));
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        int row = table.getSelectedRow();
    if (row == -1) return;

    // 1. Lấy dữ liệu từ bảng
    String tkID     = table.getValueAt(row, 0).toString();
    String email    = table.getValueAt(row, 1).toString();
    String roleName = table.getValueAt(row, 2).toString();
    String chuSoHuu = table.getValueAt(row, 3).toString();
    String trangThai= table.getValueAt(row, 4).toString();

    // 2. Lấy VTID thực sự (mã quyền) từ controller.getTaiKhoanFull
    //    giả sử controller.getTaiKhoanFull() trả List<Object[]> với [0]=ID, [1]=email, [2]=trangThai, [3]=vtid, [4]=chuSoHuu
    String vtid = "";
    for (Object[] rec : controller.getTaiKhoanFull()) {
        if (tkID.equals(rec[0])) {
            vtid = rec[3].toString();
            break;
        }
    }

    // 3. Cập nhật các field
    jTextField3.setText(tkID);
    jTextField2.setText(email);
    jTextField5.setText(chuSoHuu);

    // 4. Chọn đúng mục trong combobox: "000: Owner", "001: Admin", "002: User"
    String comboLabel = vtid + ": " + roleName;
    cbRole.setSelectedItem(comboLabel);

    // 5. Nếu là Owner thì disable combobox
    cbRole.setEnabled(!"000".equals(vtid));

    // 6. Nút khóa/mở
    if ("Đã khóa".equals(trangThai)) {
        jButton2.setVisible(true); jButton2.setText("Mở Lại");
    }
    else if ("Còn Hoạt động".equals(trangThai)) {
        jButton2.setVisible(true); jButton2.setText("Khóa Tài Khoản");
    }
    else {
        jButton2.setVisible(false);
    }

    jButton8.setVisible(true); // Đổi mật khẩu
    jButton6.setVisible(true); // Đổi Gmail

    // 7. Hiển thị ảnh
    String hinhAnh = new QLTKdao().getHinhAnhByTaiKhoan(tkID);
    hienThiAnh(hinhAnh, lbanh);
    }//GEN-LAST:event_tableMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        toggleAccountStatus();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    clearform();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    moFormThemTK();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        int row = table.getSelectedRow();
    if (row == -1) return;
    String email = table.getValueAt(row, 1).toString();
    // lấy mật khẩu hiện tại
    String currentPass = controller.getMatKhauByEmail(email);
    if (currentPass == null) {
        JOptionPane.showMessageDialog(this, "Không lấy được mật khẩu hiện tại.");
        return;
    }
    moFormDoiMatKhau(email, currentPass);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    int row = table.getSelectedRow();
    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một tài khoản để đổi Gmail.");
        return;
    }

    // Email của user cần đổi
    String targetEmail = table.getValueAt(row, 1).toString();
    // Email của admin đang đăng nhập
    String adminEmail = XAuthen.Email;

    // Mở dialog xác nhận đổi Gmail
    moFormDoiEmail(targetEmail, adminEmail);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    // Lấy các dòng được chọn
    int[] rows = table.getSelectedRows();
    if (rows.length == 0) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn tài khoản để xóa.");
        return;
    }

    // Lấy VTID (mã quyền) của dòng đầu (dòng cần xóa)
    Object[] firstRecord = controller.getTaiKhoanFull().get(rows[0]);
    String vtidToDelete = firstRecord[3].toString();

    // Nếu là Owner (VTID="000"), bắt buộc chọn thêm 1 người thừa kế
    if ("000".equals(vtidToDelete)) {
        if (rows.length < 2) {
            JOptionPane.showMessageDialog(this,
                "Bạn đang muốn xóa Owner.\n" +
                "Phải chọn thêm 1 tài khoản khác làm thừa kế quyền trước khi xóa.",
                "Chọn người thừa kế",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Lấy tài khoản thừa kế (dòng thứ 2)
        Object[] heirRecord = controller.getTaiKhoanFull().get(rows[1]);
        String heirID = heirRecord[0].toString();

        // Xác nhận
        int choice = JOptionPane.showConfirmDialog(this,
            "Bạn có chắc muốn xóa Owner \"" + firstRecord[0] + "\"\n" +
            "và chuyển quyền sang \"" + heirID + "\"?",
            "Xác nhận xóa",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) return;

        
        boolean ok = controller.xoaTaiKhoanWithHeir(firstRecord[0].toString(), heirID);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                "Xóa Owner thành công và chuyển quyền sang " + heirID + "!");
                dangNhap DN = new dangNhap();
                SwingUtilities.getWindowAncestor(this).dispose();
                 new dangNhap().setVisible(true);
                DN.setVisible(true);
                NotificationManager.showTopCenterNotification(DN, "SUCCESS", "Đăng Xuất Thành Công.");
        } else {
            JOptionPane.showMessageDialog(this,
                "Thao tác thất bại. Vui lòng thử lại.",
                "Lỗi",
                JOptionPane.ERROR_MESSAGE);
        }
    } else {
        
        String idToDelete = firstRecord[0].toString();
        int choice = JOptionPane.showConfirmDialog(this,
            "Bạn có chắc muốn xóa tài khoản \"" + idToDelete + "\"?",
            "Xác nhận xóa",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) return;

        boolean ok = controller.xoaTaiKhoan(idToDelete);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                "Xóa tài khoản thành công!");
        } else {
            JOptionPane.showMessageDialog(this,
                "Thao tác thất bại. Vui lòng thử lại.",
                "Lỗi",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    // Làm mới
    loadTaiKhoan();
    clearform();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void cbRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRoleActionPerformed
        // TODO add your handling code here:
    int row = table.getSelectedRow();
    if (row == -1) return;

    // 1) Đọc item được chọn
    String selected = (String) cbRole.getSelectedItem();        // e.g. "001: Admin"
    String[] parts   = selected.split(":", 2);
    String newVtid   = parts[0].trim();
    String newRoleName = parts[1].trim();

    // 2) Lấy record gốc
    Object[] record = controller.getTaiKhoanFull().get(row);
    String userId  = record[0].toString();
    String oldVtid = record[3].toString();
    String oldRoleName;
    switch (oldVtid) {
        case "000": oldRoleName = "Owner"; break;
        case "001": oldRoleName = "Admin"; break;
        case "002": oldRoleName = "User";  break;
        default:    oldRoleName = "Không xác định";
    }

    // 3) Nếu không thay đổi hoặc cố thay đổi Owner thì revert
    if (newVtid.equals(oldVtid)) {
        cbRole.setSelectedItem(oldVtid + ": " + oldRoleName);
        return;
    }
    if ("000".equals(oldVtid)) {
        JOptionPane.showMessageDialog(this,
            "Không thể thay đổi quyền của Owner!",
            "Không cho phép",
            JOptionPane.WARNING_MESSAGE);
        cbRole.setSelectedItem(oldVtid + ": " + oldRoleName);
        return;
    }

    // 4) Xác nhận đổi quyền
    int choice = JOptionPane.showConfirmDialog(this,
        String.format("Bạn có chắc muốn đổi quyền của \"%s\"\n"
                    + "từ %s sang %s?", userId, oldRoleName, newRoleName),
        "Xác nhận thay đổi quyền",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE
    );
    if (choice != JOptionPane.YES_OPTION) {
        cbRole.setSelectedItem(oldVtid + ": " + oldRoleName);
        return;
    }

    // 5) Gọi controller cập nhật
    boolean ok = controller.capQuyen(userId, newVtid);
    if (ok) {
        JOptionPane.showMessageDialog(this,
            "Đổi quyền thành công!",
            "Thành công",
            JOptionPane.INFORMATION_MESSAGE);
        // Reload bảng và sau đó clear detail panel
        loadTaiKhoan();
        clearform();
    } else {
        JOptionPane.showMessageDialog(this,
            "Đổi quyền thất bại. Vui lòng thử lại.",
            "Lỗi",
            JOptionPane.ERROR_MESSAGE);
        cbRole.setSelectedItem(oldVtid + ": " + oldRoleName);
    }
    }//GEN-LAST:event_cbRoleActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbRole;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JLabel lbanh;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
