/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package giaodien;
import controller.DangKyController;
import giaodien.dangNhap;
import java.awt.Color;
import javax.swing.JOptionPane;
import controller.MaXacNhanController;
import giaodien.DoiMatKhau;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author acchi
 */
public class MaXacNhan extends javax.swing.JPanel {
    private dangNhap parentFrame;
    private MaXacNhanController controller;
     private dangkyform form;
     private String actiontype;
     private String email;
     private String targetEmail;
     private String adminEmail;
     private int mouseX, mouseY;

    public MaXacNhan(dangNhap parent) {
        initComponents();
        this.parentFrame = parent;
        this.controller = new MaXacNhanController(this);
        init();
        this.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(java.awt.event.MouseEvent evt) {
        mouseX = evt.getX();
        mouseY = evt.getY();
    }
});

this.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
    public void mouseDragged(java.awt.event.MouseEvent evt) {
        dangNhap frame = parentFrame; // đã được gán sẵn từ constructor
        if (frame != null) {
            int x = evt.getXOnScreen() - mouseX;
            int y = evt.getYOnScreen() - mouseY;
            frame.setLocation(x, y);
        }
    }
});
    }

    public dangNhap getParentFrame() {
        return parentFrame;
    }
    public String getEmail() {
    return this.email;
}
    public MaXacNhan(dangkyform form, int actionType) {
        this.form = form;
        this.parentFrame = (form != null) ? form.getParentFrame() : null; // Safely get parentFrame
        this.actionType = actionType;
        initComponents();
        init();
        this.controller = new MaXacNhanController(this);
        resgitterconfirm();
        this.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(java.awt.event.MouseEvent evt) {
        mouseX = evt.getX();
        mouseY = evt.getY();
    }
});

this.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
    public void mouseDragged(java.awt.event.MouseEvent evt) {
        dangNhap frame = parentFrame; // đã được gán sẵn từ constructor
        if (frame != null) {
            int x = evt.getXOnScreen() - mouseX;
            int y = evt.getYOnScreen() - mouseY;
            frame.setLocation(x, y);
        }
    }
});
    }
    public MaXacNhan(String targetEmail, String adminEmail, int actionType) {
    initComponents();
    this.actionType   = actionType;
    this.targetEmail  = targetEmail;
    this.adminEmail   = adminEmail;
    init();
    resgitterconfirm();
    // Admin sẽ nhập Gmail mới vào ô này
    jTextField1.setText("");
    jTextField1.setEditable(true);
    jTextField1.setToolTipText("Nhập Gmail mới của user");
}
    public String getTextField1(){
        return jTextField1.getText();
    }
    
    
    
    public static final int ACTION_REGISTER = 1;
    public static final int ACTION_RESET_PASSWORD = 2;
    public static final int ACTION_CHANGE_EMAIL = 3;
    public static final int ACTION_CHANGE_EMAIL_BY_ADMIN = 4;
    

    private int actionType;

    public void setActionType(int actionType) {
    this.actionType = actionType;
}

    public int getActionType() {
        return actionType;
    }
    private void init() {
    this.controller = new MaXacNhanController(this);
}
    
public void setEmail(String email) {
    this.email = email;
    jTextField1.setText(email); // hiện email trong ô nhập nếu cần
}
public String getTargetEmail() {
    return this.targetEmail;
}
private void resgitterconfirm() {
        switch (actionType) {
            case ACTION_REGISTER:
                jButton3.setText("Cancel?");
                break;
            case ACTION_CHANGE_EMAIL:
                jButton3.setText("Hủy");
                break;
            case ACTION_CHANGE_EMAIL_BY_ADMIN:
                jButton3.setText("Hủy Đổi Gmail");
                break;
            default:
                jButton3.setText("Back Login");
        }
    }
public MaXacNhan(String emailHienTai, int actionType) {
    initComponents();
    this.controller = new MaXacNhanController(this);
    init();
    this.email = emailHienTai;
    setActionType(actionType);

    jTextField1.setText(getEmailPlaceholder()); // placeholder phù hợp với action
    jTextField1.setForeground(Color.GRAY);
    jTextField1.setEditable(true); // cho phép nhập email mới
    resgitterconfirm();
    this.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(java.awt.event.MouseEvent evt) {
        mouseX = evt.getX();
        mouseY = evt.getY();
    }
});

this.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
    public void mouseDragged(java.awt.event.MouseEvent evt) {
        dangNhap frame = parentFrame; // đã được gán sẵn từ constructor
        if (frame != null) {
            int x = evt.getXOnScreen() - mouseX;
            int y = evt.getYOnScreen() - mouseY;
            frame.setLocation(x, y);
        }
    }
});
}
private String getEmailPlaceholder() {
    if (getActionType() == ACTION_CHANGE_EMAIL) {
        return "Nhập Email Mới Của Bạn";
    } else {
        return "Nhập Email Tài Khoản Của Bạn";
    }
}
public boolean doiEmail(String emailCu, String emailMoi) {
    // Gọi DAO hoặc service để cập nhật email
    return controller.doiEmail(emailCu, emailMoi); // ví dụ
}
private boolean isValidEmailFormat(String email) {
    return email != null && email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
}
public String getAdminEmail() {
    return this.adminEmail;
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        roundedPanel1 = new giaodien.RoundedPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(176, 236, 189));

        roundedPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(25, 127, 73));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Xác Minh");

        jTextField1.setBackground(new java.awt.Color(231, 235, 236));
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("Nhập Email Tài Khoản Của Bạn");
        jTextField1.setCaretColor(new java.awt.Color(255, 255, 255));
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTextField1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTextField1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTextField1MousePressed(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jTextField2.setBackground(new java.awt.Color(231, 235, 236));
        jTextField2.setForeground(new java.awt.Color(0, 0, 0));
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField2.setText("Nhập Mã Xác Nhận Của Bạn");
        jTextField2.setCaretColor(new java.awt.Color(255, 255, 255));
        jTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField2FocusLost(evt);
            }
        });
        jTextField2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTextField2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTextField2MouseExited(evt);
            }
        });
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jButton1.setText("Gửi Mã");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.setText("Xác Nhận");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Logo.png"))); // NOI18N

        jButton3.setText("Back Login");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(325, 325, 325)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(345, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1MouseClicked

    private void jTextField2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2MouseClicked

    private void jTextField1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1MouseExited

    private void jTextField2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField2MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2MouseExited

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int action = getActionType();
    switch (action) {
        case ACTION_CHANGE_EMAIL_BY_ADMIN:
            // Chỉ đóng dialog, không làm gì thêm
            java.awt.Window win = SwingUtilities.getWindowAncestor(this);
            if (win instanceof javax.swing.JDialog) {
                win.dispose();
            }
            break;

        case ACTION_REGISTER:
            // flow đăng ký
            if (getParentFrame() != null) {
                getParentFrame().setContentPane(new dangkyform(getParentFrame()));
                getParentFrame().revalidate();
                getParentFrame().repaint();
            }
            break;

        case ACTION_CHANGE_EMAIL:
            // hủy đổi email cho user tự làm
            java.awt.Window dlg = SwingUtilities.getWindowAncestor(this);
            if (dlg instanceof javax.swing.JDialog) {
                dlg.dispose();
            }
            break;

        default:
            // RESET_PASSWORD và Back Login
            controller.backToLogin();
            break;
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_jButton3MouseClicked

    private void jTextField1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1MouseEntered

    private void jTextField2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField2MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2MouseEntered

    private void jTextField1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField1MousePressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTextField1MousePressed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        // TODO add your handling code here:
        if (jTextField1.getText().trim().isEmpty()) {
        jTextField1.setText(getEmailPlaceholder());
        jTextField1.setForeground(Color.GRAY);
    }
    }//GEN-LAST:event_jTextField1FocusLost

    private void jTextField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusGained
        // TODO add your handling code here:
        if (jTextField1.getText().equals(getEmailPlaceholder())) {
        jTextField1.setText("");
        jTextField1.setForeground(Color.BLACK);
    }
    }//GEN-LAST:event_jTextField1FocusGained

    private void jTextField2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField2FocusGained
        // TODO add your handling code here:
        if (jTextField2.getText().equals("Nhập Mã Xác Nhận Của Bạn")) {
        jTextField2.setText("");
        jTextField2.setForeground(Color.BLACK);
    }
    }//GEN-LAST:event_jTextField2FocusGained

    private void jTextField2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField2FocusLost
        // TODO add your handling code here:
        if (jTextField2.getText().trim().isEmpty()) {
        jTextField2.setText("Nhập Mã Xác Nhận Của Bạn");
        jTextField2.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_jTextField2FocusLost

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
       if (actionType == ACTION_CHANGE_EMAIL_BY_ADMIN) {
        controller.sendOTP(adminEmail);
    } else {
        // Các luồng khác: kiểm tra định dạng rồi mới gửi
        String emailNhap = jTextField1.getText().trim();
        if (!isValidEmailFormat(emailNhap)) {
            JOptionPane.showMessageDialog(this, "Email không hợp lệ!");
            return;
        }
        controller.sendOTP(emailNhap);
    }
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        String newEmail = jTextField1.getText().trim();
        String otp      = jTextField2.getText().trim();

        // validation admin-flow
        if (actionType == ACTION_CHANGE_EMAIL_BY_ADMIN) {
            if (newEmail.isEmpty() || !isValidEmailFormat(newEmail)) {
                JOptionPane.showMessageDialog(this,
                    "Gmail mới không hợp lệ! Vui lòng nhập đúng định dạng.");
                return;
            }
        } else {
            if (newEmail.isEmpty() || newEmail.equals(jTextField1.getToolTipText())) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập email!");
                return;
            }
        }
        if (otp.isEmpty() || otp.equals("Nhập Mã Xác Nhận Của Bạn")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập mã OTP!");
            return;
        }

        // xác nhận OTP
        boolean ok = controller.xacNhanOTP(
            (actionType == ACTION_CHANGE_EMAIL_BY_ADMIN)
                ? adminEmail
                : ((actionType == ACTION_CHANGE_EMAIL) ? email : newEmail),
            otp,
            actionType
        );
        if (!ok) {
            JOptionPane.showMessageDialog(this,
                "OTP sai hoặc đã hết hạn. Vui lòng thử lại.");
            return;
        }

        // thực hiện cập nhật
        boolean changed;
        if (actionType == ACTION_CHANGE_EMAIL_BY_ADMIN) {
            changed = controller.doiEmail(targetEmail, newEmail);
        } else if (actionType == ACTION_CHANGE_EMAIL) {
            changed = controller.doiEmail(email, newEmail);
        } else {
            // register / reset không dùng doiEmail ở đây
            changed = true;
        }

        if (changed) {
            JOptionPane.showMessageDialog(this,
                "Thao tác thành công!");
            // đóng dialog nếu có
            java.awt.Window win = SwingUtilities.getWindowAncestor(this);
            if (win instanceof javax.swing.JDialog) win.dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Thao tác thất bại. Vui lòng thử lại.");
        }
        
    }//GEN-LAST:event_jButton2MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private giaodien.RoundedPanel roundedPanel1;
    // End of variables declaration//GEN-END:variables
}
