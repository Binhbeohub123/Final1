
package giaodien;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import DBCONNEC.Connect;
public class PermissionManager {
    public static Map<String, Boolean> loadPermissions(String roleId, String formName) { // Thay đổi int roleId thành String roleId
        Map<String, Boolean> permissions = new HashMap<>();

        // Mặc định là không có quyền
        permissions.put("ADD", false);
        permissions.put("EDIT", false);
        permissions.put("DELETE", false);
        permissions.put("VIEW", false);

        String sql = "SELECT permission, allowed FROM Button_Permissions WHERE role_id = ? AND form_name = ?";

        try (Connection conn = Connect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, roleId); // Sử dụng setString cho roleId
            stmt.setString(2, formName);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String permission = rs.getString("permission");
                boolean allowed = rs.getBoolean("allowed");
                permissions.put(permission, allowed);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Lỗi khi tải quyền: " + e.getMessage());
            // Trả về map với tất cả quyền là false trong trường hợp lỗi
            return Map.of("ADD", false, "EDIT", false, "DELETE", false, "VIEW", false);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Lỗi chung khi tải quyền: " + e.getMessage());
            // Trả về map với tất cả quyền là false trong trường hợp lỗi
            return Map.of("ADD", false, "EDIT", false, "DELETE", false, "VIEW", false);
        }
        return permissions;
    }
}
