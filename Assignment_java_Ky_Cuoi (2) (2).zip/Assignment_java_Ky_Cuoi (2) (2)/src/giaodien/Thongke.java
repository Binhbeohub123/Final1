
package giaodien;

import controller.Doanhthucontroller;
import dao.lichsubandao;
import java.awt.GridLayout;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import poly.cafe.entity.Doanhthuenity;
import poly.cafe.entity.PMHModel;
import poly.cafe.entity.Sanpham;
import poly.cafe.entity.ThongkeNV;


public class Thongke extends javax.swing.JPanel {
private DefaultTableModel bang;
private lichsubandao dao = new lichsubandao();
private DefaultTableModel model;
private Doanhthucontroller controller = new Doanhthucontroller();
List<PMHModel> listP = new ArrayList<>();
private javax.swing.JComboBox<String> cboThoiGian;
private javax.swing.JTable tblThongKe;

    public Thongke() {
        initComponents();
           model = new DefaultTableModel();
           model = new DefaultTableModel(
        new Object[]{"Mã hóa đơn", "Ngày lập", "Tên sản phẩm", "Loại sản phẩm", "Tổng SL", "Tổng tiền", "Ghi chú", "Nhân viên", "Trạng thái"}, 
        0
    );
    jTable1.setModel(model);
    controller = new Doanhthucontroller();
    jTable1.setModel(model);
    btnloaiActionPerformed(null);
    }

    private LocalDate[] getDateRangeFromCombo() {
    String selected = cbbnam.getSelectedItem().toString(); // dùng đúng tên biến trong GUI
    LocalDate today = LocalDate.now();
    LocalDate fromDate = today;

    switch (selected) {
        case "Hôm nay":
            fromDate = today;
            break;
        case "Tuần nay":
            fromDate = today.with(DayOfWeek.MONDAY);
            break;
        case "Tháng này":
            fromDate = today.withDayOfMonth(1);
            break;
        case "Quý này":
            int quarter = (today.getMonthValue() - 1) / 3 + 1;
            fromDate = LocalDate.of(today.getYear(), (quarter - 1) * 3 + 1, 1);
            break;
        case "Năm nay":
            fromDate = today.withDayOfYear(1);
            break;
    }
    return new LocalDate[]{fromDate, today};
}
    private LocalDate[] getKhoangNgayTuNguoiDung() {
    String tuNgay = txttungay.getText().trim();
    String denNgay = txtdenngay.getText().trim();
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    sdf.setLenient(false);

    try {
        // Nếu không nhập ngày => dùng ComboBox
        if (tuNgay.trim().isEmpty() && denNgay.trim().isEmpty()) {
            return getDateRangeFromCombo();
        }

        // Nếu nhập chỉ 1 trong 2 ô
        if (tuNgay.trim().isEmpty() || denNgay.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập cả Từ ngày và Đến ngày.");
            return null;
        }

        // Nếu nhập cả 2 ô
        Date fromDate = sdf.parse(tuNgay);
        Date toDate = sdf.parse(denNgay);

        if (fromDate.after(toDate)) {
            JOptionPane.showMessageDialog(this, "Từ ngày không được sau Đến ngày.");
            return null;
        }

        LocalDate from = fromDate.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
        LocalDate to = toDate.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();

        return new LocalDate[]{from, to};

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Ngày nhập sai định dạng (dd/MM/yyyy).");
        return null;
    }
}



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txttungay = new javax.swing.JTextField();
        txtdenngay = new javax.swing.JTextField();
        btnloc = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnReset = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cbbnam = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnloai = new javax.swing.JButton();
        btnNV = new javax.swing.JButton();

        setBackground(new java.awt.Color(176, 236, 188));

        txttungay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttungayActionPerformed(evt);
            }
        });

        btnloc.setBackground(new java.awt.Color(0, 0, 0));
        btnloc.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnloc.setForeground(new java.awt.Color(255, 255, 255));
        btnloc.setText("Lọc");
        btnloc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlocActionPerformed(evt);
            }
        });

        jTable1.setBackground(new java.awt.Color(176, 236, 188));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Ma HD", "Ngày lập ", "Tên sản phẩm", "Loại sản phẩm", "Số lượng ", "Giá tiền", "Ghi chú ", "Nhân viên ", "Trạng thái"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btnReset.setBackground(new java.awt.Color(0, 0, 0));
        btnReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnReset.setText("Làm mới");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Thống kê");

        cbbnam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Năm nay", "Tháng này", "Quý này", "Tuần nay", "Hôm nay", " ", " ", " " }));
        cbbnam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbnamActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Từ ngày:");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Đến ngày:");

        btnloai.setBackground(new java.awt.Color(0, 0, 0));
        btnloai.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnloai.setForeground(new java.awt.Color(255, 255, 255));
        btnloai.setText("Doanh Thu Từng Loại");
        btnloai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnloaiActionPerformed(evt);
            }
        });

        btnNV.setBackground(new java.awt.Color(0, 0, 0));
        btnNV.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNV.setForeground(new java.awt.Color(255, 255, 255));
        btnNV.setText("Doanh Thu Từng Nhân Viên");
        btnNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNVActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1394, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(9, 9, 9))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(16, 16, 16)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txttungay, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                            .addComponent(txtdenngay))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnloc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnloai)
                .addGap(15, 15, 15)
                .addComponent(btnNV)
                .addGap(18, 18, 18)
                .addComponent(cbbnam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnloai)
                    .addComponent(btnNV)
                    .addComponent(cbbnam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txttungay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnloc))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtdenngay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReset))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 533, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txttungayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttungayActionPerformed
        
    }//GEN-LAST:event_txttungayActionPerformed

    private void btnlocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlocActionPerformed
           model.setRowCount(0);
    model.setColumnIdentifiers(new String[]{"Mã SP", "Tên SP", "Loại SP", "Doanh Thu"});

    LocalDate[] range = getKhoangNgayTuNguoiDung();
    if (range == null) return;

    List<Doanhthuenity> list = controller.getDoanhThuTheoSanPham(range[0], range[1]);

    for (Doanhthuenity dt : list) {
        model.addRow(new Object[]{
            dt.getMaSP(),
            dt.getTenSP(),
            dt.getLoaiSP(),
            dt.getDoanhThu()
        });
    }
    }//GEN-LAST:event_btnlocActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        txttungay.setText("");
        txtdenngay.setText("");
        cbbnam.setSelectedIndex(0);
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnloaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnloaiActionPerformed
     model.setRowCount(0);
    model.setColumnIdentifiers(new String[]{"Mã SP", "Tên SP", "Loại SP", "Doanh Thu"});

    LocalDate[] range = getKhoangNgayTuNguoiDung();
    if (range == null) return; // đã có thông báo lỗi

    List<Doanhthuenity> list = controller.getDoanhThuTheoSanPham(range[0], range[1]);
    for (Doanhthuenity dt : list) {
        model.addRow(new Object[]{
            dt.getMaSP(),
            dt.getTenSP(),
            dt.getLoaiSP(),
            dt.getDoanhThu()
        });
    }
    }//GEN-LAST:event_btnloaiActionPerformed

    private void btnNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNVActionPerformed
    model.setRowCount(0);
    model.setColumnIdentifiers(new String[]{"Tên Nhân Viên", "Doanh Thu", "Ngày"});

    LocalDate[] range = getKhoangNgayTuNguoiDung();
    if (range == null) return;

    List<ThongkeNV> list = controller.getDoanhThuNhanVienTheoNgay(range[0], range[1]);

    SimpleDateFormat sdfDisplay = new SimpleDateFormat("dd/MM/yyyy");

    for (ThongkeNV nv : list) {
        model.addRow(new Object[]{
            nv.getTenNV(),
            nv.getTongTien(),
            nv.getNgay() != null ? sdfDisplay.format(nv.getNgay()) : "N/A"
        });
    }

    
    }//GEN-LAST:event_btnNVActionPerformed

    private void cbbnamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbnamActionPerformed
        // TODO add your handling code here:
        if (cbbnam.getSelectedItem() != null) {
        String selected = cbbnam.getSelectedItem().toString();

        model.setRowCount(0);
        model.setColumnIdentifiers(new String[]{"Mã SP", "Tên SP", "Loại SP", "Doanh Thu"});

        LocalDate[] range = getDateRangeFromCombo();
        List<Doanhthuenity> list = controller.getDoanhThuTheoSanPham(range[0], range[1]);

        for (Doanhthuenity d : list) {
            model.addRow(new Object[]{
                d.getMaSP(),
                d.getTenSP(),
                d.getLoaiSP(),
                d.getDoanhThu()
            });
        }
    }
    }//GEN-LAST:event_cbbnamActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNV;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnloai;
    private javax.swing.JButton btnloc;
    private javax.swing.JComboBox<String> cbbnam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtdenngay;
    private javax.swing.JTextField txttungay;
    // End of variables declaration//GEN-END:variables
}
